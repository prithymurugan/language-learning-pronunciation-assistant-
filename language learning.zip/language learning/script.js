function speakTarget() {

    const text =
        document.getElementById("target").value;

    const speech =
        new SpeechSynthesisUtterance(text);

    speech.lang = "en-IN";

    speechSynthesis.speak(speech);
}

function startPractice() {

    if (!("webkitSpeechRecognition" in window)) {
        alert("Speech recognition is not supported.");
        return;
    }

    const recognition =
        new webkitSpeechRecognition();

    recognition.lang = "en-IN";
    recognition.continuous = false;

    recognition.onresult = function(event) {

        const spoken =
            event.results[0][0].transcript;

        const target =
            document.getElementById("target")
            .value
            .toLowerCase();

        document.getElementById("spoken").innerText =
            "You said: " + spoken;

        if (spoken.toLowerCase().trim() === target.trim()) {

            document.getElementById("result").innerText =
                "Result: ✅ Correct";

        } else {

            document.getElementById("result").innerText =
                "Result: ❌ Try Again";
        }
    };

    recognition.start();
}